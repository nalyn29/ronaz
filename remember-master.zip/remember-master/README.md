# Remember

Offline web app to remember locations, also available as a [starter kit](https://github.com/paulhoughton/react-pwa/)

Navigate to https://paulhoughton.github.io/remember/ on your phone then _Add to Home screen_ for offline use

![](https://github.com/paulhoughton/remember/blob/gh-pages/example.png)
